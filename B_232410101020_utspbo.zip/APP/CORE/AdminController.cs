﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using $safeprojectname$.App.Context;
using $safeprojectname$.App.Model;
using Npgsql;

namespace $safeprojectname$.App.Core
{
    public class AdminController
    {
      private DatabaseConnection dbConnection = new DatabaseConnection();

      public void AddAdmin(M_Admin admin)
      {
            using (var conn = dbConnection.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO admin (judul, deskripsi, deadline) VALUES (@judul, @deskripsi, @deadline)*";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@judul", admin.judul);
                    cmd.Parameters.AddWithValue("@deskripsi", admin.deskripsi);
                    cmd.Parameters.AddWithValue("@deadline", admin.deadline);
                }
            }
        }
    }
  }
