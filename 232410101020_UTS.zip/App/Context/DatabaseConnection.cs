﻿using Npgsql;
using System;
namespace B_232410101020_utspbo.App.Context
{
    public class DatabaseConnection
    {
        private string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=Karinsya;Database=B_232410101020_utspbo";
        public NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(connectionString);
        }
    }
}
