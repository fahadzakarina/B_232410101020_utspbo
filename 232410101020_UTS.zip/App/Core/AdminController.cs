﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using B_232410101020_utspbo.App.Context;
using B_232410101020_utspbo.App.Model;
using Npgsql;

namespace B_232410101020_utspbo.App.Core
{
    public class AdminController
    {
      private DatabaseConnection dbConnection = new DatabaseConnection();

      public void AddAdmin(M_Admin admin)
      {
            using (var conn = dbConnection.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO admin (judul, deskripsi, deadline) VALUES (@judul, @deskripsi, @deadline)*";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@judul", admin.judul);
                    cmd.Parameters.AddWithValue("@deskripsi", admin.deskripsi);
                    cmd.Parameters.AddWithValue("@deadline", admin.deadline);
                }
            }
        }
    }
  }
