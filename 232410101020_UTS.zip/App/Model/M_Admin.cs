﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_232410101020_utspbo.App.Model
{
    public class M_Admin
    {
        [Key] 
        public string judul { get; set; }
        [Required]
        public string deskripsi { get; set; }
        [Required]
        public string  deadline { get; set; }
    }
}
