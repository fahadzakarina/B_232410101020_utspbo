﻿using Npgsql;
using System;
namespace $safeprojectname$.App.Context
{
    public class DatabaseConnection
    {
        private string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=Karinsya;Database=$safeprojectname$";
        public NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(connectionString);
        }
    }
}
